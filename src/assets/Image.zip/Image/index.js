import slide1 from './slide1.jpg'
import slide2 from './slide2.jpeg'
import slide3 from './slide3.jpeg'
import slide4 from './slide4.jpg'
import slide5 from './slide5.jpg'
import slide6 from './slide6.jpg'
import slide7 from './slide7.jpg'
import pink from './pink.jpg'
import oval from './Oval.png'
import plannerslk from './plannerslk.png'
import OnlineSupport from './OnlineSupport.png'
import EasyReturns from './EasyReturns.png'
import PaymentSecure from './paymentsecure.png'
import Shipping from './Shipping.png'
import login from './login.jpg'
import lushforest from './lush-forest.webp'
import lushforest1 from './lush-forest1.webp'
import three from './three.webp'
import four from './four.webp'
import five from './five.webp'
import six from './six.webp'
import seven from './seven.webp'






export {
slide1,
slide2,
slide3,
slide4,
slide5,
slide6,
slide7,
pink,
oval,
plannerslk,
OnlineSupport,
EasyReturns,
PaymentSecure,
Shipping,
login,
lushforest,
lushforest1,
three,four,five,six,seven,
}